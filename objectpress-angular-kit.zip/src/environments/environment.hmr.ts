export const environment = {
  production: false,
  hmr: true,
  appId: "2dc26aa8-ebe0-4c3a-a43d-8f68123aaa65",
  clientId: "a9efbd45-9242-4840-ab37-a4ef5fd468ab"
};
